# Job Listing Portal

This repository contains a full-stack job listing portal application built as a collaborative project. The core idea is to link job seekers with employers through a clean, modern interface, complete with user profiles, job postings, applications, and dashboards.

## Overview

- **Backend**: Node.js with Express, MongoDB for database, Mongoose for ORM.
- **Frontend**: React (Create React App) for user interface.

## Features

1. **User Authentication**
   - Registration and login
   - JWT-based authentication
   - Secure password hashing with bcrypt

2. **Profile Management**
   - Job seeker and employer profiles
   - Update personal/company information and resume

3. **Job Listings**
   - Employers can create, edit, delete job posts
   - Listings include title, description, qualifications, responsibilities, location, salary
   - Search and filter jobs by keyword/location

4. **Job Applications**
   - Seekers can apply to jobs with optional cover letter
   - Employers can view applications for their postings
   - Application status updates

5. **Dashboards**
   - Separate views for seekers and employers to manage content

## Getting Started

### Backend

1. Navigate to `backend` folder:
   ```bash
   cd backend
   ```
2. Install dependencies:
   ```bash
   npm install
   ```
3. Copy `.env.example` to `.env` and configure:
   ```bash
   cp .env.example .env
   # set MONGO_URI, JWT_SECRET, PORT as needed
   ```
4. Start the server:
   ```bash
   npm run dev   # requires nodemon
   # or npm start
   ```

### Frontend

1. Navigate to `frontend` and install packages:
   ```bash
   cd frontend
   npm install
   ```
2. Start development server:
   ```bash
   npm start
   ```

## Contact

Support: support@amdox.in

## Team

This project was developed by the following contributors:

- Yash
- Mohit
- Faraz
- Kasim
- Anshika
- Rajendra

Each member contributed to both backend and frontend components, working together to deliver a cohesive job listing portal.

---

This portal is designed to help job seekers find their dream job and employers connect with talent efficiently.
## Database & Code Structure

All persistent data is stored in MongoDB and managed by the backend server. Here’s how everything fits together:

- **Backend entrypoint**: `backend/index.js` – connects to the MongoDB database (using `MONGO_URI` from environment variables), sets up middleware and attaches route handlers.
- **Models** (`backend/models/`): define the shape of the data.
  - `User.js` – user profiles (job seekers & employers).
  - `Job.js` – job listings posted by employers.
  - `Application.js` – applications made by seekers for jobs.
- **Routes** (`backend/routes/`): expose API endpoints that perform CRUD operations on the models.
  - `auth.js` – registration/login and JWT issuance.
  - `jobs.js` – create, read, update, delete jobs; search filtering.
  - `applications.js` – apply to jobs, view applications (seeker/employer), update status.
  - `users.js` – retrieve/update current user profile.
- **Middleware**: `backend/middleware/auth.js` validates the JWT on protected routes and populates `req.user` with the decoded payload, allowing role-based access checks in route handlers.

- **Frontend interaction**: located in `frontend/src/services/`; API calls use Axios to communicate with these endpoints. Components invoke these services and update UI state accordingly.

- **Data flow**: an incoming request hits an Express route, optionally passes through auth middleware, then uses a Mongoose model method (e.g. `Job.find`, `new Application()`) which reads/writes documents in the MongoDB collections. Responses are sent back to the client in JSON format.

This section should help you quickly locate where data is stored and how the backend code interfaces with the database.
