import React, { useState, useEffect } from 'react';
import API from '../services/api';

const Dashboard = ({ user }) => {
  const [applications, setApplications] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [employerApps, setEmployerApps] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        if (user.role === 'seeker') {
          const res = await API.get('/applications/me');
          setApplications(res.data);
        } else if (user.role === 'employer') {
          const resJobs = await API.get('/jobs');
          // filter by employer maybe? backend returns all but we will only show
          setJobs(resJobs.data.filter(j => j.employer._id === user.id));
          const resApps = await API.get('/applications/employer');
          setEmployerApps(resApps.data);
        }
      } catch (err) {
        console.error(err);
      }
    };
    fetchData();
  }, [user]);

  return (
    <div className="container">
      <h2>Dashboard</h2>
      {user.role === 'seeker' && (
        <div>
          <h3>Your Applications</h3>
          <ul className="list-group">
            {applications.map(app => (
              <li key={app._id} className="list-group-item">
                {app.job.title} - {app.status}
              </li>
            ))}
          </ul>
        </div>
      )}
      {user.role === 'employer' && (
        <div>
          <h3>Your Jobs</h3>
          <ul className="list-group mb-4">
            {jobs.map(job => (
              <li key={job._id} className="list-group-item">
                {job.title}
              </li>
            ))}
          </ul>
          <h3>Applications Received</h3>
          <ul className="list-group">
            {employerApps.map(app => (
              <li key={app._id} className="list-group-item">
                {app.applicant.name} applied for {app.job.title} - {app.status}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default Dashboard;