import React, { useState, useEffect } from 'react';
import API from '../services/api';
import { Link } from 'react-router-dom';

const JobList = () => {
  const [jobs, setJobs] = useState([]);
  const [keyword, setKeyword] = useState('');
  const [location, setLocation] = useState('');

  const fetchJobs = React.useCallback(async () => {
    const params = {};
    if (keyword) params.keyword = keyword;
    if (location) params.location = location;
    const res = await API.get('/jobs', { params });
    setJobs(res.data);
  }, [keyword, location]);

  useEffect(() => {
    fetchJobs();
  }, [fetchJobs]);

  const handleSearch = e => {
    e.preventDefault();
    fetchJobs();
  };

  return (
    <div className="container">
      <h2>Job Listings</h2>
      <form className="row g-3 mb-4" onSubmit={handleSearch}>
        <div className="col-md-4">
          <input
            type="text"
            className="form-control"
            placeholder="Keyword"
            value={keyword}
            onChange={e => setKeyword(e.target.value)}
          />
        </div>
        <div className="col-md-4">
          <input
            type="text"
            className="form-control"
            placeholder="Location"
            value={location}
            onChange={e => setLocation(e.target.value)}
          />
        </div>
        <div className="col-md-4">
          <button type="submit" className="btn btn-primary">Search</button>
        </div>
      </form>
      <ul className="list-group">
        {jobs.map(job => (
          <li key={job._id} className="list-group-item">
            <Link to={`/jobs/${job._id}`}>{job.title}</Link> - {job.location}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default JobList;