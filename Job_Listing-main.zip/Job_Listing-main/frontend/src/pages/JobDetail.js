import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import API from '../services/api';

const JobDetail = ({ user }) => {
  const { id } = useParams();
  const [job, setJob] = useState(null);
  const [coverLetter, setCoverLetter] = useState('');
  const [message, setMessage] = useState(null);

  useEffect(() => {
    const fetchJob = async () => {
      const res = await API.get(`/jobs/${id}`);
      setJob(res.data);
    };
    fetchJob();
  }, [id]);

  const apply = async () => {
    try {
      await API.post('/applications', { jobId: id, coverLetter });
      setMessage('Application submitted');
    } catch (err) {
      setMessage(err.response?.data?.message || 'Error');
    }
  };

  if (!job) return <div className="container">Loading...</div>;

  return (
    <div className="container">
      <h2>{job.title}</h2>
      <p>{job.description}</p>
      <p><strong>Location:</strong> {job.location}</p>
      <p><strong>Salary:</strong> {job.salaryRange}</p>
      {user && user.role === 'seeker' && (
        <div className="mt-4">
          <h4>Apply</h4>
          {message && <div className="alert alert-info">{message}</div>}
          <textarea
            className="form-control mb-2"
            rows="4"
            placeholder="Cover letter"
            value={coverLetter}
            onChange={e => setCoverLetter(e.target.value)}
          />
          <button className="btn btn-primary" onClick={apply}>Submit Application</button>
        </div>
      )}
    </div>
  );
};

export default JobDetail;