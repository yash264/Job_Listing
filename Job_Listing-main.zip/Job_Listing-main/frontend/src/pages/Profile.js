import React, { useState, useEffect } from 'react';
import { getProfile, updateProfile } from '../services/auth';

const Profile = ({ user, setUser }) => {
  const [form, setForm] = useState({ name: '', contactDetails: '', resumeUrl: '', companyInfo: '' });
  const [message, setMessage] = useState(null);

  useEffect(() => {
    const load = async () => {
      try {
        const res = await getProfile();
        setForm(res.data);
      } catch (err) {
        console.error(err);
      }
    };
    load();
  }, []);

  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    try {
      const res = await updateProfile(form);
      setUser(res.data);
      setMessage('Profile updated');
    } catch (err) {
      setMessage('Error saving profile');
    }
  };

  return (
    <div className="container">
      <h2>Profile</h2>
      {message && <div className="alert alert-info">{message}</div>}
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">Name</label>
          <input
            name="name"
            type="text"
            className="form-control"
            value={form.name || ''}
            onChange={handleChange}
          />
        </div>
        {user.role === 'seeker' && (
          <>
            <div className="mb-3">
              <label className="form-label">Resume URL</label>
              <input
                name="resumeUrl"
                type="text"
                className="form-control"
                value={form.resumeUrl || ''}
                onChange={handleChange}
              />
            </div>
            <div className="mb-3">
              <label className="form-label">Contact Details</label>
              <input
                name="contactDetails"
                type="text"
                className="form-control"
                value={form.contactDetails || ''}
                onChange={handleChange}
              />
            </div>
          </>
        )}
        {user.role === 'employer' && (
          <div className="mb-3">
            <label className="form-label">Company Info</label>
            <textarea
              name="companyInfo"
              className="form-control"
              rows="3"
              value={form.companyInfo || ''}
              onChange={handleChange}
            />
          </div>
        )}
        <button className="btn btn-primary" type="submit">Save</button>
      </form>
    </div>
  );
};

export default Profile;