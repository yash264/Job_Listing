# Job Listing Portal (Frontend)

This folder contains the React user interface for the Job Listing Portal project. The application provides pages for user registration, login, browsing job postings, applying to jobs, and managing profiles/dashboards for both job seekers and employers.

## Features

- Routing with React Router for seamless navigation
- Authentication flow tied to backend API
- Job search with filters and detail pages
- Seeker and employer dashboards
- Forms for posting jobs, applying to jobs, and updating profiles
- Bootstrap styling for a clean responsive layout

## Setup & Development

1. Install dependencies:
   ```bash
   cd frontend
   npm install
   ```
2. Start the development server:
   ```bash
   npm start
   ```
   The app will be available at `http://localhost:3000` (or a forwarded port in Codespaces).

3. Build for production:
   ```bash
   npm run build
   ```
   The static assets will be generated in the `build/` directory and can be served by the backend or any static hosting service.

## Team

This front-end was implemented collaboratively by:

- Yash
- Mohit
- Faraz
- Kasim
- Anshika
- Rajendra

## Support

For any issues or questions, contact the project team at support@amdox.in.

---

This application works in tandem with the Express/Mongo backend located in `../backend`.