# Job Listing Portal

This backend folder contains the API server for the Job Listing Portal, a full-stack application developed by a six-member team. The API handles authentication, user profiles, job postings, applications, and related data.

## Features

- User registration and login with JWT
- Protected routes using middleware
- CRUD operations for jobs and applications
- Role-based access control (seeker vs employer)
- MongoDB via Mongoose as the data store

## Team

This project was built collaboratively by:

- Yash
- Mohit
- Faraz
- Kasim
- Anshika
- Rajendra

## Setup

1. Copy `.env.example` to `.env` and configure environment variables.
2. Install dependencies with `npm install`.
3. Start the server with `npm run dev` (requires nodemon) or `npm start`.

Support: support@amdox.in
