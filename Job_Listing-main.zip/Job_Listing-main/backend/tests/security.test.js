const request = require('supertest');
const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
let app;

beforeAll(async () => {
  const mongoServer = await MongoMemoryServer.create();
  await mongoose.connect(mongoServer.getUri(), { useNewUrlParser: true, useUnifiedTopology: true });
  app = require('../index');
});

afterAll(async () => {
  await mongoose.disconnect();
  await mongoose.connection.close();
});

describe('Security & authentication checks', () => {
  let token;

  it('allows login after registration', async () => {
    await request(app)
      .post('/api/auth/register')
      .send({ name: 'SecTest', email: 'sec@example.com', password: 'pass1234', role: 'seeker' });

    const res = await request(app)
      .post('/api/auth/login')
      .send({ email: 'sec@example.com', password: 'pass1234' });

    expect(res.statusCode).toBe(200);
    expect(res.body.token).toBeDefined();
    token = res.body.token;
  });

  it('denies access to protected route without token', async () => {
    const res = await request(app).get('/api/users/me');
    expect(res.statusCode).toBe(401);
  });

  it('allows access to protected route with valid token', async () => {
    const res = await request(app)
      .get('/api/users/me')
      .set('Authorization', `Bearer ${token}`);
    expect(res.statusCode).toBe(200);
    expect(res.body.email).toBe('sec@example.com');
  });
});