const request = require('supertest');
const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
let app;
let token;

beforeAll(async () => {
  const mongoServer = await MongoMemoryServer.create();
  await mongoose.connect(mongoServer.getUri(), { useNewUrlParser: true, useUnifiedTopology: true });
  app = require('../index');
  // register and login an employer
  await request(app)
    .post('/api/auth/register')
    .send({ name: 'Emp', email: 'emp@example.com', password: 'password', role: 'employer' });
  const res = await request(app)
    .post('/api/auth/login')
    .send({ email: 'emp@example.com', password: 'password' });
  token = res.body.token;
});

afterAll(async () => {
  await mongoose.disconnect();
  await mongoose.connection.close();
});

describe('Job routes', () => {
  it('should allow employer to post a job', async () => {
    const res = await request(app)
      .post('/api/jobs')
      .set('Authorization', `Bearer ${token}`)
      .send({ title: 'Job1', description: 'desc', location: 'Anywhere' });
    expect(res.statusCode).toBe(201);
    expect(res.body.title).toBe('Job1');
  });
  it('should list jobs', async () => {
    const res = await request(app).get('/api/jobs');
    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });
});
