const express = require('express');
const Application = require('../models/Application');
const Job = require('../models/Job');
const auth = require('../middleware/auth');

const router = express.Router();

// Apply to a job (seeker)
router.post('/', auth, async (req, res) => {
  try {
    if (req.user.role !== 'seeker') return res.status(403).json({ message: 'Forbidden' });
    const { jobId, coverLetter } = req.body;
    const job = await Job.findById(jobId);
    if (!job) return res.status(404).json({ message: 'Job not found' });
    const existing = await Application.findOne({ job: jobId, applicant: req.user.id });
    if (existing) return res.status(400).json({ message: 'Already applied' });
    const application = new Application({ job: jobId, applicant: req.user.id, coverLetter });
    await application.save();
    res.status(201).json(application);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get applications for employer's jobs
router.get('/employer', auth, async (req, res) => {
  try {
    if (req.user.role !== 'employer') return res.status(403).json({ message: 'Forbidden' });
    const jobs = await Job.find({ employer: req.user.id });
    const jobIds = jobs.map(j => j._id);
    const applications = await Application.find({ job: { $in: jobIds } }).populate('applicant', 'name email');
    res.json(applications);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get applications for a seeker
router.get('/me', auth, async (req, res) => {
  try {
    if (req.user.role !== 'seeker') return res.status(403).json({ message: 'Forbidden' });
    const applications = await Application.find({ applicant: req.user.id }).populate('job');
    res.json(applications);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update application status (employer)
router.put('/:id/status', auth, async (req, res) => {
  try {
    if (req.user.role !== 'employer') return res.status(403).json({ message: 'Forbidden' });
    const app = await Application.findById(req.params.id).populate('job');
    if (!app) return res.status(404).json({ message: 'Not found' });
    if (app.job.employer.toString() !== req.user.id) return res.status(403).json({ message: 'Forbidden' });
    app.status = req.body.status;
    await app.save();
    res.json(app);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
